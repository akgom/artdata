from flask import Flask, render_template, jsonify
import gspread
from oauth2client.service_account import ServiceAccountCredentials

app = Flask(__name__)

# Define the scope
scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']

creds = ServiceAccountCredentials.from_json_keyfile_name('drhsscolastic-69cc1ba6b0ff.json', scope)

# Authorize the client
client = gspread.authorize(creds)

@app.route('/')
def leaderboard():
    sheet = client.open('DRHSART ALL-TIME SCHOLASTIC AWARDS test').sheet1

    # Get all values from the sheet
    values = sheet.get_all_values()

    # Extract data from columns 1 (name), 2 (year), and 3 (points)
    leaderboard_data = [{'name': row[0], 'year': row[1], 'points': row[2]} for row in values]

    # Sort the data by points (assuming points are numerical)
    leaderboard_data.sort(key=lambda x: int(x['points']), reverse=True)

    # Render the leaderboard HTML template with the leaderboard data
    return render_template('leaderboard.html', leaderboard_data=leaderboard_data)

if __name__ == '__main__':
    app.run(debug=True)
